function[compare_2_data_sets]=menu()
clc
clear all
close all
choice = menu('Choose a opcion','explaine','limite','expfun','exit of menu');
    switch choice
        case 1
            explaine='matlab';
            display(explaine);
          case 2
              syms x
              limit((x-2)/(x^2-4),2)
          case 3
              x = input('Please enter a value for x: ');
              expfn=inline('sin(x)+5');
              expfn(x)
          otherwise 
              display('thanks');
      end
end

